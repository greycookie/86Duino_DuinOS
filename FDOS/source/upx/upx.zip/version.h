#define UPX_VERSION_HEX         0x030800        /* 03.08.00 */
#define UPX_VERSION_STRING      "3.08"
#define UPX_VERSION_STRING4     "3.08"
#define UPX_VERSION_DATE        "Dec 12th 2011"
#define UPX_VERSION_DATE_ISO    "2011-12-12"
#define UPX_VERSION_YEAR        "2011"
