#define EX_USAGE 0x40
