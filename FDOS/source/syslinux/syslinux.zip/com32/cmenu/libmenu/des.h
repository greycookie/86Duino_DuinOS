
#ifndef _DES_H_
#define _DES_H_

// des crypt
extern char *crypt(const char *key, const char *salt);

#endif
