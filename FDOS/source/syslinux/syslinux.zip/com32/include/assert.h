#ifndef _ASSERT_H
#define _ASSERT_H

/* Assert not currently supported */
#define assert(X) ((void)0)

#endif /* _ASSERT_H */
