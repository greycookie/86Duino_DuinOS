/*
 * errno.c
 *
 */
#include <errno.h>

int errno;
