#define TYPE unsigned long long
#define NAME strtoull
#include "strtox.c"
