#include "file.h"

struct file_info __file_info[NFILES];
