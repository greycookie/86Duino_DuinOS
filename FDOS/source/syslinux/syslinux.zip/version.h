#define VERSION 4.05
#define VERSION_STR "4.05"
#define VERSION_MAJOR 4
#define VERSION_MINOR 5
#define YEAR 2011
#define YEAR_STR "2011"
